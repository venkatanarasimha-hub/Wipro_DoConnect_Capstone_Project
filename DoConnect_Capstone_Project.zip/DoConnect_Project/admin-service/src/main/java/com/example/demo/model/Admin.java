package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "admin")
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long adminId;
    private String adminName;
    private String username;
    private String email;
    private String mobile;
    private String password;
    @Column(columnDefinition = "BOOLEAN DEFAULT TRUE")
    private boolean active = true;
    
}
