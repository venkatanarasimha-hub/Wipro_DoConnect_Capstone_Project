package com.example.demo.service;

import com.example.demo.model.Admin;
import com.example.demo.repository.AdminRepository;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    private final AdminRepository repo;

    public AdminService(AdminRepository repo) {
        this.repo = repo;
    }

    public Admin register(Admin admin) {
        return repo.save(admin);
    }

    public Admin login(String adminName, String password) {

        Admin admin = repo.findByAdminName(adminName);

        if (admin != null && admin.getPassword().equals(password)) {
            return admin;
        }

        return null;
    }
}

