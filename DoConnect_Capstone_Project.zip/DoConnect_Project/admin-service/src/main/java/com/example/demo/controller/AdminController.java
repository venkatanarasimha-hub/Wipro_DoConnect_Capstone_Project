package com.example.demo.controller;

import com.example.demo.model.Admin;
import com.example.demo.repository.AdminRepository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private final AdminRepository repo;

    public AdminController(AdminRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/register")
    public Admin register(@RequestBody Admin admin) {
        return repo.save(admin);
    }

    @PostMapping("/login")
    public Admin login(@RequestBody Admin loginReq) {

        // find admin by adminName
        Admin admin = repo.findByAdminName(loginReq.getAdminName());

        if (admin == null) return null;
        if (!admin.getPassword().equals(loginReq.getPassword())) return null;

        return admin;
    }
}

