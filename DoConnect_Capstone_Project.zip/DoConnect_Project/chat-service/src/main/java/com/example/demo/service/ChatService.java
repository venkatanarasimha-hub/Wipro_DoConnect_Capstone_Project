package com.example.demo.service;

import com.example.demo.model.Chat;
import com.example.demo.repository.ChatRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class ChatService {

    private final ChatRepository repo;

    public ChatService(ChatRepository repo) {
        this.repo = repo;
    }

    public Chat send(Chat chat) {
        return repo.save(chat);
    }

    public List<Chat> getChatHistory(Long user1, Long user2) {

        List<Chat> messages1 =
                repo.findBySenderIdAndReceiverIdOrderByChatIdAsc(user1, user2);

        List<Chat> messages2 =
                repo.findBySenderIdAndReceiverIdOrderByChatIdAsc(user2, user1);

        List<Chat> allMessages = new ArrayList<>();
        allMessages.addAll(messages1);
        allMessages.addAll(messages2);

        allMessages.sort(Comparator.comparing(Chat::getChatId));

        return allMessages;
    }
}


