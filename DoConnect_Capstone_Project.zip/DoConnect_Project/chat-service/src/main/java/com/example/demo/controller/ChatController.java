package com.example.demo.controller;

import com.example.demo.model.Chat;
import com.example.demo.service.ChatService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chat")
public class ChatController {

    private final ChatService service;

    public ChatController(ChatService service) {
        this.service = service;
    }

    
    @PostMapping("/send")
    public Chat sendMessage(@RequestBody Chat chat) {
        return service.send(chat);
    }

    
    @GetMapping("/history/{user1}/{user2}")
    public List<Chat> getChatHistory(@PathVariable Long user1, @PathVariable Long user2) {
        return service.getChatHistory(user1, user2);
    }
}
