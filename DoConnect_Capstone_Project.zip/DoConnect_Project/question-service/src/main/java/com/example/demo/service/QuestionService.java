package com.example.demo.service;

import com.example.demo.model.Question;
import com.example.demo.repository.QuestionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {

    private final QuestionRepository repo;

    public QuestionService(QuestionRepository repo) {
        this.repo = repo;
    }
    public List<Question> getPending() {
        return repo.findByStatus(Question.Status.PENDING);
    }


   
    public List<Question> getAll() {
        return repo.findAll();
    }

    public Question get(Long id) {
        return repo.findById(id).orElse(null);
    }

    public List<Question> getByUser(Long id) {
        return repo.findByAskedBy(id);
    }

    public Question ask(Question q) {
        q.setStatus(Question.Status.PENDING);  
        return repo.save(q);
    }


    public Question approve(Long id) {
        Question q = get(id);
        q.setStatus(Question.Status.APPROVED);
        return repo.save(q);
    }

    public Question reject(Long id) {
        Question q = get(id);
        q.setStatus(Question.Status.REJECTED);
        return repo.save(q);
    }
    public void delete(Long id) {
        repo.deleteById(id);
    }

}

 
