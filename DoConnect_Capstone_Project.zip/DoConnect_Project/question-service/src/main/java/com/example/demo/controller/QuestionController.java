package com.example.demo.controller;

import com.example.demo.model.Question;
import com.example.demo.service.QuestionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/question")
public class QuestionController {

    private final QuestionService service;

    public QuestionController(QuestionService service) {
        this.service = service;
    }

    @PostMapping("/ask")
    public Question ask(@RequestBody Question q) {
        return service.ask(q);
    }

    @GetMapping("/all")
    public List<Question> all() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Question get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping("/user/{userId}")
    public List<Question> getByUser(@PathVariable Long userId) {
        return service.getByUser(userId);
    }

    @GetMapping("/pending")
    public List<Question> pending() {
        return service.getPending();
    }

    @PutMapping("/{id}/approve")
    public Question approve(@PathVariable Long id) {
        return service.approve(id);
    }

    @PutMapping("/{id}/reject")
    public Question reject(@PathVariable Long id) {
        return service.reject(id);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

}



