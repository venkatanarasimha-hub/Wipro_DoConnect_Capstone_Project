package com.example.demo.controller;

import com.example.demo.model.Answer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Controller
@RequestMapping("/admin/answers")
public class AdminAnswerApprovalController {

    private final WebClient answerClient = WebClient.builder()
            .baseUrl("http://localhost:8084")   
            .build();

    @GetMapping("/pending")
    public String pendingAnswers(Model model) {

        List<Answer> pending = answerClient.get()
                .uri("/answer/pending")
                .retrieve()
                .bodyToFlux(Answer.class)
                .collectList()
                .block();

        model.addAttribute("answers", pending);
        return "admin-pending-answers";
    }

    @GetMapping("/{id}/approve")
    public String approve(@PathVariable Long id) {

        answerClient.put()
                .uri("/answer/" + id + "/approve")
                .retrieve()
                .bodyToMono(Void.class)
                .block();

        return "redirect:/admin/answers/pending";
    }

    @GetMapping("/{id}/reject")
    public String reject(@PathVariable Long id) {

        answerClient.put()
                .uri("/answer/" + id + "/reject")
                .retrieve()
                .bodyToMono(Void.class)
                .block();

        return "redirect:/admin/answers/pending";
    }
}
