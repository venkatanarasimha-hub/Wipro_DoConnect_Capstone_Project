package com.example.demo.controller;

import com.example.demo.model.Answer;
import com.example.demo.model.Question;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Controller
@RequestMapping("/question")
public class UserQuestionViewController {

	private final WebClient qClient = WebClient.builder()
	        .baseUrl("http://QUESTION-SERVICE")
	        .build();


    @GetMapping("/view/{id}")
    public String viewQuestion(@PathVariable Long id, Model model) {

        Question q = qClient.get()
                .uri("/question/" + id)
                .retrieve()
                .bodyToMono(Question.class)
                .block();

        List<Answer> answers = qClient.get()
                .uri("/answer/question/" + id)
                .retrieve()
                .bodyToFlux(Answer.class)
                .collectList()
                .block();

        model.addAttribute("question", q);
        model.addAttribute("answers", answers);

        return "view-question";
    }
}
