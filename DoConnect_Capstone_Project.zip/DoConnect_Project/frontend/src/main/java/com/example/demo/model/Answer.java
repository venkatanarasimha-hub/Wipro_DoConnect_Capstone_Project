package com.example.demo.model;

import lombok.Data;

@Data
public class Answer {
    private Long answerId;
    private Long questionId;
    private String answerText;
    private Long answeredBy;
    private String imageUrl;
    private String status;
}
