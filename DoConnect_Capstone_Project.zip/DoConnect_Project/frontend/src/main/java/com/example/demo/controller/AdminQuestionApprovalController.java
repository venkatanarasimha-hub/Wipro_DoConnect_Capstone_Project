package com.example.demo.controller;

import com.example.demo.model.Question;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Controller
@RequestMapping("/admin/questions")   
public class AdminQuestionApprovalController {

    private final WebClient qClient = WebClient.builder()
            .baseUrl("http://localhost:8083")   
            .build();

    @GetMapping("/pending")
    public String pendingQuestions(Model model) {

        List<Question> list = qClient.get()
                .uri("/question/pending")
                .retrieve()
                .bodyToFlux(Question.class)
                .collectList()
                .block();

        model.addAttribute("questions", list);
        return "admin-pending-questions";  
    }

    @GetMapping("/{id}/approve")
    public String approve(@PathVariable Long id) {

        qClient.put()
                .uri("/question/" + id + "/approve")
                .retrieve()
                .bodyToMono(Void.class)
                .block();

        return "redirect:/admin/questions/pending";
    }

    @GetMapping("/{id}/reject")
    public String reject(@PathVariable Long id) {

        qClient.put()
                .uri("/question/" + id + "/reject")
                .retrieve()
                .bodyToMono(Void.class)
                .block();

        return "redirect:/admin/questions/pending";
    }
}
