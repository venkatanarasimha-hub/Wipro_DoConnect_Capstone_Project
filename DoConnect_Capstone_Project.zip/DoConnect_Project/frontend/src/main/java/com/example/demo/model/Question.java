package com.example.demo.model;

import lombok.Data;

@Data
public class Question {
    private Long questionId;
    private String title;
    private String description;
    private String imageUrl;
    private Long askedBy;
    private String status;
}

