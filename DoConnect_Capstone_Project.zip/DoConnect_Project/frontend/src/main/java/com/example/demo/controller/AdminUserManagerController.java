package com.example.demo.controller;

import com.example.demo.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Controller
@RequestMapping("/admin/users")
public class AdminUserManagerController {

    private final WebClient userClient = WebClient.builder()
            .baseUrl("http://localhost:8081")
            .build();

    @GetMapping
    public String listUsers(Model model) {

        List<User> users = userClient.get()
                .uri("/user/all")
                .retrieve()
                .bodyToFlux(User.class)
                .collectList()
                .block();

        model.addAttribute("users", users);
        return "admin-manage-users";
    }

    @GetMapping("/deactivate/{id}")
    public String deactivate(@PathVariable Long id) {
        userClient.put()
                .uri("/user/deactivate/" + id)
                .retrieve()
                .toBodilessEntity()
                .block();
        return "redirect:/admin/users";
    }

    @GetMapping("/activate/{id}")
    public String activate(@PathVariable Long id) {
        userClient.put()
                .uri("/user/activate/" + id)
                .retrieve()
                .toBodilessEntity()
                .block();
        return "redirect:/admin/users";
    }
}

