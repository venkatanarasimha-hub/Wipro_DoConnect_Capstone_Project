package com.example.demo.controller;

import com.example.demo.model.Chat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import com.example.demo.model.User;
import java.util.List;

@Controller
@RequestMapping("/chat")
public class UserChatController {

    private final WebClient chatClient = WebClient.builder()
            .baseUrl("http://localhost:8085")   
            .build();
    
    private final WebClient userClient = WebClient.builder()
            .baseUrl("http://localhost:8081")   
            .build();

    // Open chat page between two users
    @GetMapping("/open")
    public String openChat(@RequestParam Long userId,
                           @RequestParam Long otherId,
                           Model model) {

        System.out.println("OPEN CHAT userId=" + userId + " otherId=" + otherId);

        List<Chat> history = chatClient.get()
        		.uri("/chat/history/" + userId + "/" + otherId)
                .retrieve()
                .bodyToFlux(Chat.class)
                .collectList()
                .block();

        System.out.println("Chat history: " + history);

        model.addAttribute("messages", history);
        model.addAttribute("userId", userId);
        model.addAttribute("otherId", otherId);  

        return "chat";
    }


    // Send a message
    @PostMapping("/send")
    public String sendMessage(@RequestParam Long senderId,
                              @RequestParam Long receiverId,
                              @RequestParam String message) {

        Chat chat = new Chat();
        chat.setSenderId(senderId);
        chat.setReceiverId(receiverId);
        chat.setMessage(message);

        chatClient.post()
                .uri("/chat/send")
                .bodyValue(chat)
                .retrieve()
                .bodyToMono(Chat.class)
                .block();

        return "redirect:/chat/open?userId=" + senderId + "&otherId=" + receiverId;
    }
    @GetMapping("/users")
    public String selectUserToChat(@RequestParam Long userId, Model model) {

        // Fetch all users from user-service
        List<User> users = userClient.get()
                .uri("/user/all")
                .retrieve()
                .bodyToFlux(User.class)
                .collectList()
                .block();

        // Remove logged-in user from list (cannot chat with self)
        users.removeIf(u -> u.getId().equals(userId));

        model.addAttribute("users", users);
        model.addAttribute("userId", userId);

        return "chat-users"; 
    }

}
