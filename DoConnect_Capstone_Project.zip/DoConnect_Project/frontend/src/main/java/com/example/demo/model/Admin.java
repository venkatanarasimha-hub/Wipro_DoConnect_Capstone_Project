package com.example.demo.model;

import lombok.Data;

@Data
public class Admin {

    private Long adminId;
    private String adminName;
    private String username;
    private String email;
    private String mobile;
    private String password;
}
