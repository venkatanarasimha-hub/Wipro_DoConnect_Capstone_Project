package com.example.demo.controller;

import com.example.demo.model.Answer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

@Controller
@RequestMapping("/answer")
public class UserAnswerController {

    private final WebClient aClient = WebClient.builder()
            .baseUrl("http://localhost:8084")  
            .build();

    @GetMapping("/add/{qid}")
    public String addAnswerPage(@PathVariable Long qid, Model model) {
        model.addAttribute("questionId", qid);
        return "add-answer";
    }

    @PostMapping("/add")
    public String addAnswer(Answer a) {

        aClient.post()
                .uri("/answer/submit")  
                .bodyValue(a)
                .retrieve()
                .bodyToMono(Answer.class)
                .block();

        return "redirect:/questions/view/" + a.getQuestionId() + "?userId=" + a.getAnsweredBy();

    }
}
