package com.example.demo.controller;

import com.example.demo.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserAuthController {

    private final WebClient userClient = WebClient.builder()
            .baseUrl("http://localhost:8081")
            .build();

    @GetMapping("/login")
    public String loginPage() {
        return "user-login";
    }

    @PostMapping("/doLogin")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          Model model) {

        try {
            User user = userClient.post()
                    .uri("/user/login")
                    .bodyValue(Map.of("username", username, "password", password))
                    .retrieve()
                    .bodyToMono(User.class)
                    .block();

            if (user == null) {
                model.addAttribute("error", "Invalid username or password");
                return "user-login";
            }

            if (!user.isActive()) {
                model.addAttribute("error", "Your account is deactivated.");
                return "user-login";
            }

            model.addAttribute("message", "Login successful!");
            model.addAttribute("user", user);
            model.addAttribute("userId", user.getId());
            model.addAttribute("userName", user.getName());
            return "user-dashboard";

        } catch (WebClientResponseException.Forbidden ex) {
            model.addAttribute("error", "Your account is deactivated.");
            return "user-login";
        } catch (WebClientResponseException ex) {
            model.addAttribute("error", "Invalid username or password");
            return "user-login";
        } catch (Exception ex) {
            model.addAttribute("error", "Something went wrong. Try again.");
            return "user-login";
        }
    }

    @GetMapping("/register")
    public String registerPage() {
        return "user-register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {
        try {
            User saved = userClient.post()
                    .uri("/user/register")
                    .bodyValue(user)
                    .retrieve()
                    .bodyToMono(User.class)
                    .block();

            model.addAttribute("message", "Registration Successful!");
            return "user-login";

        } catch (Exception e) {
            model.addAttribute("error", "Registration failed");
            return "user-register";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam Long userId, Model model) {

        User user = userClient.get()
                .uri("/user/" + userId)
                .retrieve()
                .bodyToMono(User.class)
                .block();

        model.addAttribute("user", user);
        model.addAttribute("userId", user.getId());
        model.addAttribute("userName", user.getName());

        return "user-dashboard";
    }

    @GetMapping("/logout")
    public String logout() {
        return "redirect:/";
    }
}
