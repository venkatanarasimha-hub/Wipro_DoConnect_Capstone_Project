package com.example.demo.controller;

import com.example.demo.model.Question;
import com.example.demo.model.Answer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;

@Controller
@RequestMapping("/questions")
public class UserQuestionController {
	


    private final WebClient questionClient = WebClient.builder()
            .baseUrl("http://localhost:8083")
            .build();

    private final WebClient answerClient = WebClient.builder()
            .baseUrl("http://localhost:8084")
            .build();

    // ----------------  ASK QUESTION PAGE ----------------
    @GetMapping("/ask")
    public String askQuestionPage(@RequestParam Long userId, Model model) {
        model.addAttribute("userId", userId);
        return "ask-question";
    }

    // ---------------- SUBMIT QUESTION ----------------
    @PostMapping("/ask")
    public String submitQuestion(@RequestParam Long userId,
                                 @RequestParam String title,
                                 @RequestParam(required = false) String description,
                                 @RequestParam(required = false) String imageUrl,
                                 Model model) {

        Question q = new Question();
        q.setTitle(title);
        q.setDescription(description);
        q.setImageUrl(imageUrl);
        q.setAskedBy(userId);

        questionClient.post()
                .uri("/question/ask")
                .bodyValue(q)
                .retrieve()
                .bodyToMono(Question.class)
                .block();

        return "redirect:/user/dashboard?userId=" + userId + "&msg=Question Submitted Successfully";
    }



    // ---------------- MY QUESTIONS LIST ----------------
    @GetMapping("/my-questions")
    public String myQuestions(@RequestParam Long userId, Model model) {

        List<Question> questions = questionClient.get()
                .uri("/question/user/" + userId)
                .retrieve()
                .bodyToFlux(Question.class)
                .collectList()
                .block();

        model.addAttribute("questions", questions);
        model.addAttribute("userId", userId);

        return "my-questions";
    }

    // ---------------- DELETE QUESTION ----------------
    @GetMapping("/delete/{id}")
    public String deleteQuestion(@PathVariable Long id, @RequestParam Long userId) {

        questionClient.delete()
                .uri("/question/" + id)
                .retrieve()
                .bodyToMono(Void.class)
                .block();

        return "redirect:/questions/my-questions?userId=" + userId;
    }

    // ---------------- VIEW QUESTION + ANSWERS ----------------
    @GetMapping("/view/{id}")
    public String viewQuestion(@PathVariable Long id,
                               @RequestParam Long userId,
                               Model model) {

        Question q = questionClient.get()
                .uri("/question/" + id)
                .retrieve()
                .bodyToMono(Question.class)
                .block();

        WebClient answerClient = WebClient.builder()
                .baseUrl("http://localhost:8084")
                .build();

        List<Answer> answers = answerClient.get()
                .uri("/answer/question/" + id)
                .retrieve()
                .bodyToFlux(Answer.class)
                .collectList()
                .block();

        model.addAttribute("question", q);
        model.addAttribute("answers", answers);
        model.addAttribute("userId", userId);

        return "view-question";
    }

    // ---------------- VIEW ALL QUESTIONS ----------------
    @GetMapping("/all")
    public String allQuestions(@RequestParam Long userId, Model model) {

        List<Question> list = questionClient.get()
                .uri("/question/all")
                .retrieve()
                .bodyToFlux(Question.class)
                .collectList()
                .block();

        model.addAttribute("questions", list);
        model.addAttribute("userId", userId);

        return "all-questions";
    }

    @PostMapping("/answer")
    public String submitAnswer(@RequestParam Long questionId,
                               @RequestParam Long userId,
                               @RequestParam String answerText) {

        WebClient answerClient = WebClient.builder()
                .baseUrl("http://localhost:8084")
                .build();

        Answer ans = new Answer();
        ans.setQuestionId(questionId);
        ans.setAnsweredBy(userId);
        ans.setAnswerText(answerText);

        answerClient.post()
                .uri("/answer/submit")
                .bodyValue(ans)
                .retrieve()
                .bodyToMono(Answer.class)
                .block();

        return "redirect:/questions/view/" + questionId + "?userId=" + userId;
    }

    
}


