package com.example.demo.model;

import lombok.Data;
import java.time.LocalDateTime;
@Data
public class Chat {

    private Long chatId;
    private Long senderId;
    private Long receiverId;
    private String message;
    private LocalDateTime createdAt;

}

