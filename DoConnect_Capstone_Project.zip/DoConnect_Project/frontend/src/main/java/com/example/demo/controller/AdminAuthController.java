package com.example.demo.controller;

import com.example.demo.model.Admin;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

@Controller
@RequestMapping("/admin")
public class AdminAuthController {

    private final WebClient adminClient = WebClient.builder()
            .baseUrl("http://localhost:8082")   // ✅ FIXED URL
            .build();

    // ---------------- LOGIN PAGE ----------------
    @GetMapping("/login")
    public String loginPage() {
        return "admin-login";
    }

    // ---------------- DO LOGIN ----------------
    @PostMapping("/doLogin")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          Model model) {
        try {

            Admin loginReq = new Admin();
            loginReq.setAdminName(username);
            loginReq.setPassword(password);

            Admin admin = adminClient.post()
                    .uri("/admin/login")          
                    .bodyValue(loginReq)         
                    .retrieve()
                    .bodyToMono(Admin.class)
                    .block();

            if (admin == null) {
                model.addAttribute("error", "Invalid admin credentials");
                return "admin-login";
            }

            model.addAttribute("admin", admin);
            return "admin-dashboard";            

        } catch (Exception e) {
            model.addAttribute("error", "Admin login failed");
            return "admin-login";
        }
    }

    // ---------------- REGISTER PAGE ----------------
    @GetMapping("/register")
    public String registerPage() {
        return "admin-register";
    }

    // ---------------- ADMIN REGISTER ----------------
    @PostMapping("/register")
    public String registerAdmin(Admin admin, Model model) {
        try {
            Admin saved = adminClient.post()
                    .uri("/admin/register")       
                    .bodyValue(admin)
                    .retrieve()
                    .bodyToMono(Admin.class)
                    .block();

            model.addAttribute("message", "Admin registration successful! Please login.");
            return "admin-login";

        } catch (Exception e) {
            model.addAttribute("error", "Registration failed");
            return "admin-register";
        }
    }

    // ---------------- LOGOUT ----------------
    @GetMapping("/logout")
    public String logout() {
        return "redirect:/";
    }
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        return "admin-dashboard";
    }

    
}

