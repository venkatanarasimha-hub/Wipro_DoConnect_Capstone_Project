package com.example.demo.service;

import com.example.demo.model.Answer;
import com.example.demo.repository.AnswerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerService {

    private final AnswerRepository repo;

    public AnswerService(AnswerRepository repo) {
        this.repo = repo;
    }

    public Answer submit(Answer answer) {
        answer.setStatus(Answer.Status.PENDING);   
        return repo.save(answer);
    }


    public List<Answer> getPending() {
        return repo.findByStatus(Answer.Status.PENDING);
    }

    public Answer approve(Long id) {
        Answer a = repo.findById(id).orElse(null);
        if (a != null) {
            a.setStatus(Answer.Status.APPROVED);
            repo.save(a);
        }
        return a;
    }

    public Answer reject(Long id) {
        Answer a = repo.findById(id).orElse(null);
        if (a != null) {
            a.setStatus(Answer.Status.REJECTED);
            repo.save(a);
        }
        return a;
    }
    public List<Answer> getApprovedAnswers(Long qid) {
        return repo.findByQuestionIdAndStatus(qid, Answer.Status.APPROVED);
    }

}

