package com.example.demo.controller;

import com.example.demo.model.Answer;
import com.example.demo.service.AnswerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/answer")
public class AnswerController {

    private final AnswerService service;

    public AnswerController(AnswerService service) {
        this.service = service;
    }

    @PostMapping("/submit")
    public Answer submit(@RequestBody Answer answer) {
        return service.submit(answer);
    }

    @GetMapping("/pending")
    public List<Answer> pending() {
        return service.getPending();
    }

    @PutMapping("/{id}/approve")
    public Answer approve(@PathVariable Long id) {
        return service.approve(id);
    }

    @PutMapping("/{id}/reject")
    public Answer reject(@PathVariable Long id) {
        return service.reject(id);
    }
    @GetMapping("/question/{questionId}")
    public List<Answer> getByQuestion(@PathVariable Long questionId) {
        return service.getApprovedAnswers(questionId);
    }


}
