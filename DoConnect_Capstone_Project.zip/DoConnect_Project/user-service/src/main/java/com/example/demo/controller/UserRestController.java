package com.example.demo.controller;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
import com.example.demo.exception.AccountDeactivatedException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserRestController {

    private final UserService service;

    public UserRestController(UserService service) {
        this.service = service;
    }

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return service.register(user);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginRequest) {
        try {
            User user = service.login(loginRequest.getUsername(), loginRequest.getPassword());
            if (user == null) {
                return ResponseEntity.status(401).body("Invalid username or password");
            }
            return ResponseEntity.ok(user);

        } catch (AccountDeactivatedException ex) {
            return ResponseEntity.status(403).body(ex.getMessage());
        }
    }

    @GetMapping("/{id}")
    public User getUser(@PathVariable Long id) {
        return service.getById(id);
    }

    @GetMapping("/all")
    public List<User> getAllUsers() {
        return service.getAllUsers();
    }

    @PutMapping("/deactivate/{id}")
    public String deactivate(@PathVariable Long id) {
        service.deactivate(id);
        return "User deactivated";
    }

    @PutMapping("/activate/{id}")
    public String activate(@PathVariable Long id) {
        service.activate(id);
        return "User activated";
    }
}


