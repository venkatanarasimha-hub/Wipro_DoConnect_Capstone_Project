package com.example.demo.exception;

public class AccountDeactivatedException extends RuntimeException {
    public AccountDeactivatedException(String msg) {
        super(msg);
    }
}
