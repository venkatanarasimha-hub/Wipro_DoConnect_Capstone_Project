package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.exception.AccountDeactivatedException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository repo;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    public User register(User user) {
        user.setActive(true);
        return repo.save(user);
    }

    public User login(String username, String password) {
        User u = repo.findByUsername(username);
        if (u == null) return null;
        if (!u.getPassword().equals(password)) return null;
        if (!u.isActive()) {
            throw new AccountDeactivatedException("Your account is deactivated.");
        }
        return u;
    }

    public User getById(Long id) {
        return repo.findById(id).orElse(null);
    }

    public List<User> getAllUsers() {
        return repo.findAll();
    }

    public void deactivate(Long id) {
        User u = repo.findById(id).orElse(null);
        if (u != null) {
            u.setActive(false);
            repo.save(u);
        }
    }

    public void activate(Long id) {
        User u = repo.findById(id).orElse(null);
        if (u != null) {
            u.setActive(true);
            repo.save(u);
        }
    }
}
